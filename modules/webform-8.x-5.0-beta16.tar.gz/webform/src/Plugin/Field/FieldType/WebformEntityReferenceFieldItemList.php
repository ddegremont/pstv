<?php

namespace Drupal\webform\Plugin\Field\FieldType;

use Drupal\Core\Field\EntityReferenceFieldItemList;

/**
 * Defines a item list class for webform entity reference fields.
 */
class WebformEntityReferenceFieldItemList extends EntityReferenceFieldItemList {

}
