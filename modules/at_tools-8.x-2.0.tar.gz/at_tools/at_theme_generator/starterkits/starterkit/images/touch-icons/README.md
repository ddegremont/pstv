# Touch Icons

Included is a generic set of icons to cover most iOS and Android devices.

Each icon has a setting in the Touch icon extension.

Please see this excellent article on touch icons for more info:
https://mathiasbynens.be/notes/touch-icons

