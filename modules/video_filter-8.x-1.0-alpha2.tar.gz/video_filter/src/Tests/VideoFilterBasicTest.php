<?php

/**
 * @file
 * Contains \Drupal\video_filter\Tests\VideoFilterBasicTest.
 */

namespace Drupal\video_filter\Tests;

use Drupal\simpletest\WebTestBase;

/**
 * Test basic functionality of Video Filter module.
 *
 * @group Video Filter
 */
class VideoFilterBasicTest extends WebTestBase {

  /**
   * {@inheritdoc}
   */
  protected function setUp() {
    parent::setUp();
  }

}
